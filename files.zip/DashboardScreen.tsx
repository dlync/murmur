import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  Animated,
} from 'react-native';
import { colors } from '../constants/theme';
import { TAGS, getDailyQuote, formatDate } from '../constants/data';
import { Thought, UserStats } from '../hooks/useThoughts';

interface Props {
  thoughts: Thought[];
  user: UserStats;
  onAdd: (body: string, tag: string) => void;
}

export default function DashboardScreen({ thoughts, user, onAdd }: Props) {
  const [body, setBody] = useState('');
  const [activeTag, setActiveTag] = useState('');
  const [saving, setSaving] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const quote = getDailyQuote();
  const recent = thoughts.slice(0, 8);

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  function handleTagPress(tag: string) {
    setActiveTag(activeTag === tag ? '' : tag);
  }

  async function handleSave() {
    const trimmed = body.trim();
    if (!trimmed) {
      Alert.alert('Empty entry', 'Write something before saving.');
      return;
    }
    setSaving(true);
    await onAdd(trimmed, activeTag);
    setBody('');
    setActiveTag('');
    setSaving(false);
  }

  return (
    <KeyboardAvoidingView
      style={styles.root}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={0}
    >
      <ScrollView
        style={styles.scroll}
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* Identity strip */}
          <View style={styles.identityStrip}>
            <View style={styles.rule} />
            <Text style={styles.username}>{user.username}</Text>
          </View>

          {/* Title */}
          <Text style={styles.title}>
            What are you{'\n'}
            <Text style={styles.titleItalic}>thinking?</Text>
          </Text>

          {/* Daily quote */}
          <Text style={styles.quote}>"{quote}"</Text>

          {/* Stats row */}
          <View style={styles.statsRow}>
            <View style={styles.stat}>
              <Text style={[styles.statNum, styles.accentNum]}>{user.streak}</Text>
              <Text style={styles.statLabel}>Day streak</Text>
            </View>
            <View style={[styles.stat, styles.statBorder]}>
              <Text style={styles.statNum}>{user.thoughtsToday}</Text>
              <Text style={styles.statLabel}>Today</Text>
            </View>
            <View style={[styles.stat, styles.statBorder]}>
              <Text style={styles.statNum}>{user.thoughtsTotal}</Text>
              <Text style={styles.statLabel}>Total</Text>
            </View>
          </View>

          {/* Divider */}
          <View style={styles.divider} />

          {/* Compose section */}
          <View style={styles.composeSection}>
            <View style={styles.composeLabelRow}>
              <View style={styles.smallRule} />
              <Text style={styles.composeLabel}>New entry</Text>
            </View>

            {/* Tag pills */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.tagScroll}
              contentContainerStyle={styles.tagContainer}
            >
              {TAGS.map((tag) => (
                <TouchableOpacity
                  key={tag}
                  style={[styles.tagPill, activeTag === tag && styles.tagPillActive]}
                  onPress={() => handleTagPress(tag)}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.tagText, activeTag === tag && styles.tagTextActive]}>
                    {tag}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {/* Text area */}
            <TextInput
              style={styles.textarea}
              multiline
              placeholder="Begin anywhere. There's no wrong way in…"
              placeholderTextColor={colors.border2}
              value={body}
              onChangeText={setBody}
              textAlignVertical="top"
            />

            {/* Footer row */}
            <View style={styles.composeFooter}>
              <TouchableOpacity
                style={[styles.saveBtn, saving && styles.saveBtnDisabled]}
                onPress={handleSave}
                disabled={saving}
                activeOpacity={0.8}
              >
                <Text style={styles.saveBtnText}>{saving ? 'Saving…' : 'Save entry'}</Text>
              </TouchableOpacity>
              <Text style={styles.charCount}>{body.length} / ∞</Text>
            </View>
          </View>

          {/* Divider */}
          <View style={styles.divider} />

          {/* Recent entries */}
          <View style={styles.recentSection}>
            <Text style={styles.recentLabel}>Recent</Text>

            {recent.length === 0 ? (
              <Text style={styles.emptyText}>Your entries will appear here.</Text>
            ) : (
              recent.map((thought) => (
                <View key={thought.id} style={styles.entryCard}>
                  <View style={styles.entryMeta}>
                    <Text style={styles.entryDate}>{formatDate(thought.timestamp)}</Text>
                    {thought.tag ? <Text style={styles.entryTag}>{thought.tag}</Text> : null}
                  </View>
                  <Text style={styles.entryBody} numberOfLines={3}>
                    {thought.body}
                  </Text>
                </View>
              ))
            )}
          </View>
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  scroll: { flex: 1 },
  scrollContent: {
    padding: 28,
    paddingBottom: 60,
  },

  // Identity
  identityStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
  },
  rule: { width: 14, height: 1, backgroundColor: colors.accent },
  username: {
    fontFamily: 'System',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
    color: colors.muted,
  },

  // Title
  title: {
    fontFamily: 'Georgia',
    fontSize: 32,
    fontWeight: '300',
    lineHeight: 38,
    color: colors.bright,
    letterSpacing: -0.5,
    marginBottom: 20,
  },
  titleItalic: {
    fontStyle: 'italic',
    color: colors.accent,
  },

  // Quote
  quote: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 13,
    color: colors.muted,
    lineHeight: 22,
    marginBottom: 24,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },

  // Stats
  statsRow: {
    flexDirection: 'row',
    marginBottom: 24,
  },
  stat: { flex: 1 },
  statBorder: {
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
    paddingLeft: 14,
  },
  statNum: {
    fontFamily: 'Georgia',
    fontSize: 28,
    fontWeight: '300',
    color: colors.bright,
    lineHeight: 32,
    marginBottom: 3,
  },
  accentNum: { color: colors.accent },
  statLabel: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: colors.muted,
  },

  divider: {
    height: 1,
    backgroundColor: colors.border,
    marginBottom: 28,
  },

  // Compose
  composeSection: { marginBottom: 8 },
  composeLabelRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  smallRule: { width: 14, height: 1, backgroundColor: colors.accent },
  composeLabel: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 1.4,
    textTransform: 'uppercase',
    color: colors.muted,
  },

  // Tags
  tagScroll: { marginBottom: 12 },
  tagContainer: { gap: 6, paddingRight: 4 },
  tagPill: {
    borderWidth: 1,
    borderColor: colors.border2,
    paddingHorizontal: 10,
    paddingVertical: 5,
    backgroundColor: 'transparent',
  },
  tagPillActive: {
    borderColor: colors.accent,
    backgroundColor: colors.accentL,
  },
  tagText: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  tagTextActive: { color: colors.accentD },

  // Textarea
  textarea: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    padding: 16,
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 15,
    color: colors.text,
    lineHeight: 26,
    minHeight: 160,
    marginBottom: 12,
  },

  // Footer
  composeFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 28,
  },
  saveBtn: {
    backgroundColor: colors.accent,
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  saveBtnDisabled: { backgroundColor: colors.muted },
  saveBtnText: {
    fontFamily: 'System',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: colors.white,
  },
  charCount: {
    marginLeft: 'auto',
    fontSize: 11,
    color: colors.muted,
    fontFamily: 'System',
  },

  // Recent
  recentSection: {},
  recentLabel: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    color: colors.muted,
    marginBottom: 12,
  },
  emptyText: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 13,
    color: colors.muted,
    paddingVertical: 16,
  },
  entryCard: {
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingVertical: 14,
  },
  entryMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
  },
  entryDate: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  entryTag: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.accent,
  },
  entryBody: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 13,
    color: colors.dim,
    lineHeight: 21,
  },
});
