import { useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export interface Thought {
  id: string;
  body: string;
  tag: string;
  timestamp: string; // ISO string
}

export interface UserStats {
  username: string;
  streak: number;
  thoughtsToday: number;
  thoughtsTotal: number;
}

const THOUGHTS_KEY = '@murmur_thoughts';
const USER_KEY = '@murmur_user';

const DEFAULT_USER: UserStats = {
  username: 'wanderer',
  streak: 1,
  thoughtsToday: 0,
  thoughtsTotal: 0,
};

export function useThoughts() {
  const [thoughts, setThoughts] = useState<Thought[]>([]);
  const [user, setUser] = useState<UserStats>(DEFAULT_USER);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      const [t, u] = await Promise.all([
        AsyncStorage.getItem(THOUGHTS_KEY),
        AsyncStorage.getItem(USER_KEY),
      ]);
      const loadedThoughts: Thought[] = t ? JSON.parse(t) : [];
      const loadedUser: UserStats = u ? JSON.parse(u) : DEFAULT_USER;

      // Recalculate today's count
      const today = new Date().toDateString();
      const todayCount = loadedThoughts.filter(
        (th) => new Date(th.timestamp).toDateString() === today
      ).length;

      setThoughts(loadedThoughts);
      setUser({ ...loadedUser, thoughtsToday: todayCount, thoughtsTotal: loadedThoughts.length });
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }

  async function addThought(body: string, tag: string) {
    const newThought: Thought = {
      id: Date.now().toString(),
      body,
      tag,
      timestamp: new Date().toISOString(),
    };
    const updated = [newThought, ...thoughts];
    setThoughts(updated);

    const today = new Date().toDateString();
    const todayCount = updated.filter(
      (th) => new Date(th.timestamp).toDateString() === today
    ).length;
    const newUser = { ...user, thoughtsToday: todayCount, thoughtsTotal: updated.length };
    setUser(newUser);

    await AsyncStorage.setItem(THOUGHTS_KEY, JSON.stringify(updated));
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(newUser));
  }

  async function deleteThought(id: string) {
    const updated = thoughts.filter((t) => t.id !== id);
    setThoughts(updated);
    const today = new Date().toDateString();
    const todayCount = updated.filter(
      (th) => new Date(th.timestamp).toDateString() === today
    ).length;
    const newUser = { ...user, thoughtsToday: todayCount, thoughtsTotal: updated.length };
    setUser(newUser);
    await AsyncStorage.setItem(THOUGHTS_KEY, JSON.stringify(updated));
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(newUser));
  }

  async function updateUsername(name: string) {
    const newUser = { ...user, username: name };
    setUser(newUser);
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(newUser));
  }

  return { thoughts, user, loading, addThought, deleteThought, updateUsername };
}
