import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Alert,
} from 'react-native';
import { colors } from '../constants/theme';
import { TAGS, formatDate, formatFullDate } from '../constants/data';
import { Thought, UserStats } from '../hooks/useThoughts';

interface Props {
  thoughts: Thought[];
  user: UserStats;
  onDelete: (id: string) => void;
}

export default function ArchiveScreen({ thoughts, user, onDelete }: Props) {
  const [search, setSearch] = useState('');
  const [filterTag, setFilterTag] = useState('');

  const filtered = useMemo(() => {
    return thoughts.filter((t) => {
      const matchSearch = search === '' || t.body.toLowerCase().includes(search.toLowerCase());
      const matchTag = filterTag === '' || t.tag === filterTag;
      return matchSearch && matchTag;
    });
  }, [thoughts, search, filterTag]);

  function confirmDelete(id: string) {
    Alert.alert('Delete entry', 'Are you sure you want to delete this entry?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => onDelete(id) },
    ]);
  }

  const renderItem = ({ item }: { item: Thought }) => (
    <TouchableOpacity
      style={styles.thoughtItem}
      onLongPress={() => confirmDelete(item.id)}
      activeOpacity={0.7}
    >
      <View style={styles.thoughtMeta}>
        <Text style={styles.thoughtTimestamp}>{formatDate(item.timestamp)}</Text>
        {item.tag ? <Text style={styles.thoughtTag}>{item.tag}</Text> : null}
      </View>
      <Text style={styles.thoughtBody}>{item.body}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.root}>
      {/* Stats header */}
      <View style={styles.statsHeader}>
        <View style={styles.statBox}>
          <Text style={styles.statNum}>{user.streak}</Text>
          <Text style={styles.statLabel}>Streak</Text>
        </View>
        <View style={[styles.statBox, styles.statBorder]}>
          <Text style={styles.statNum}>{user.thoughtsToday}</Text>
          <Text style={styles.statLabel}>Today</Text>
        </View>
        <View style={[styles.statBox, styles.statBorder]}>
          <Text style={[styles.statNum, styles.accentNum]}>{user.thoughtsTotal}</Text>
          <Text style={styles.statLabel}>Total</Text>
        </View>
        <View style={[styles.statBox, styles.statBorder]}>
          <Text style={styles.statNum}>
            {new Set(thoughts.map((t) => t.tag).filter(Boolean)).size}
          </Text>
          <Text style={styles.statLabel}>Tags used</Text>
        </View>
      </View>

      {/* Filter bar */}
      <View style={styles.filterBar}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search entries…"
          placeholderTextColor={colors.border2}
          value={search}
          onChangeText={setSearch}
        />
        {(search || filterTag) ? (
          <TouchableOpacity
            style={styles.clearBtn}
            onPress={() => { setSearch(''); setFilterTag(''); }}
          >
            <Text style={styles.clearBtnText}>Clear</Text>
          </TouchableOpacity>
        ) : null}
      </View>

      {/* Tag filter chips */}
      <View style={styles.tagRow}>
        {TAGS.map((tag) => (
          <TouchableOpacity
            key={tag}
            style={[styles.tagChip, filterTag === tag && styles.tagChipActive]}
            onPress={() => setFilterTag(filterTag === tag ? '' : tag)}
            activeOpacity={0.7}
          >
            <Text style={[styles.tagChipText, filterTag === tag && styles.tagChipTextActive]}>
              {tag}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Results count */}
      <View style={styles.resultsRow}>
        <Text style={styles.resultsText}>
          {filtered.length} {filtered.length === 1 ? 'entry' : 'entries'}
          {(search || filterTag) ? ' found' : ''}
        </Text>
        <Text style={styles.hintText}>Long-press to delete</Text>
      </View>

      {/* List */}
      {filtered.length === 0 ? (
        <Text style={styles.emptyText}>
          {thoughts.length === 0
            ? 'Your archive is empty. Start writing on the Today tab.'
            : 'No entries match your search.'}
        </Text>
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          renderItem={renderItem}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bg,
  },

  // Stats
  statsHeader: {
    flexDirection: 'row',
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.surface,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  statBox: { flex: 1, alignItems: 'center' },
  statBorder: {
    borderLeftWidth: 1,
    borderLeftColor: colors.border,
  },
  statNum: {
    fontFamily: 'Georgia',
    fontSize: 22,
    fontWeight: '300',
    color: colors.bright,
    lineHeight: 26,
    marginBottom: 2,
  },
  accentNum: { color: colors.accent },
  statLabel: {
    fontFamily: 'System',
    fontSize: 8,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },

  // Filter
  filterBar: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  searchInput: {
    flex: 1,
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontFamily: 'System',
    fontSize: 13,
    fontWeight: '300',
    color: colors.text,
  },
  clearBtn: {
    borderWidth: 1,
    borderColor: colors.border2,
    paddingHorizontal: 14,
    paddingVertical: 10,
  },
  clearBtnText: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },

  // Tag chips
  tagRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 6,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  tagChip: {
    borderWidth: 1,
    borderColor: colors.border2,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  tagChipActive: {
    borderColor: colors.accent,
    backgroundColor: colors.accentL,
  },
  tagChipText: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  tagChipTextActive: { color: colors.accentD },

  // Results
  resultsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  resultsText: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  hintText: {
    fontFamily: 'System',
    fontSize: 9,
    color: colors.border2,
    fontStyle: 'italic',
  },

  // Empty
  emptyText: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 13,
    color: colors.muted,
    padding: 28,
    lineHeight: 22,
  },

  // List
  listContent: { paddingBottom: 40 },
  thoughtItem: {
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  thoughtMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  thoughtTimestamp: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  thoughtTag: {
    fontFamily: 'System',
    fontSize: 9,
    fontWeight: '600',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    color: colors.accent,
  },
  thoughtBody: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 14,
    color: colors.text,
    lineHeight: 24,
    fontWeight: '300',
  },
});
