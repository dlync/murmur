import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  StatusBar,
  TouchableOpacity,
  SafeAreaView,
  Platform,
} from 'react-native';
import { colors } from './constants/theme';
import { useThoughts } from './hooks/useThoughts';
import DashboardScreen from './components/DashboardScreen';
import ArchiveScreen from './components/ArchiveScreen';
import ProfileScreen from './components/ProfileScreen';

type Tab = 'today' | 'archive' | 'profile';

export default function App() {
  const [activeTab, setActiveTab] = React.useState<Tab>('today');
  const { thoughts, user, loading, addThought, deleteThought, updateUsername } = useThoughts();

  if (loading) {
    return (
      <View style={styles.loading}>
        <Text style={styles.loadingText}>murmur.</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <StatusBar barStyle="dark-content" backgroundColor={colors.bg} />

      {/* Nav header */}
      <View style={styles.nav}>
        <Text style={styles.navLogo}>
          murmur<Text style={styles.navLogoDot}>.</Text>
        </Text>
        <View style={styles.navLinks}>
          <TouchableOpacity onPress={() => setActiveTab('today')} style={styles.navItem}>
            <Text style={[styles.navLink, activeTab === 'today' && styles.navLinkActive]}>
              Today
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setActiveTab('archive')} style={styles.navItem}>
            <Text style={[styles.navLink, activeTab === 'archive' && styles.navLinkActive]}>
              Archive
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setActiveTab('profile')} style={styles.navItem}>
            <Text style={[styles.navLink, activeTab === 'profile' && styles.navLinkActive]}>
              Profile
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Content */}
      <View style={styles.content}>
        {activeTab === 'today' && (
          <DashboardScreen thoughts={thoughts} user={user} onAdd={addThought} />
        )}
        {activeTab === 'archive' && (
          <ArchiveScreen thoughts={thoughts} user={user} onDelete={deleteThought} />
        )}
        {activeTab === 'profile' && (
          <ProfileScreen thoughts={thoughts} user={user} onUpdateUsername={updateUsername} />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: colors.bg,
  },
  loading: {
    flex: 1,
    backgroundColor: colors.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingText: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontSize: 24,
    fontWeight: '300',
    color: colors.muted,
  },

  // Nav
  nav: {
    height: 50,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
    backgroundColor: colors.bg,
    gap: 20,
  },
  navLogo: {
    fontFamily: 'Georgia',
    fontStyle: 'italic',
    fontWeight: '300',
    fontSize: 17,
    color: colors.bright,
    letterSpacing: 0.2,
    flexShrink: 0,
  },
  navLogoDot: {
    color: colors.accent,
    fontStyle: 'normal',
  },
  navLinks: {
    flexDirection: 'row',
    marginLeft: 'auto',
    gap: 20,
    alignItems: 'center',
  },
  navItem: { paddingVertical: 4 },
  navLink: {
    fontFamily: 'System',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: colors.muted,
  },
  navLinkActive: { color: colors.accent },

  // Content
  content: { flex: 1 },
});
